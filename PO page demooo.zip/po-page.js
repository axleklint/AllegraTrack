// Demo only: orders live in the page and disappear on refresh.
// Replace with real save/load calls once the backend and PostgreSQL are ready.

const form = document.getElementById('po-form');
const recentHeader = document.getElementById('recent-header');
const toast = document.getElementById('toast');

const supplier = document.getElementById('supplier');
const item = document.getElementById('item');
const qty = document.getElementById('qty');
const cost = document.getElementById('cost');
const date = document.getElementById('date');

let nextNumber = 4; // PO-0001 to PO-0003 already exist as sample rows

function poNumber(n) {
  return 'PO-' + String(n).padStart(4, '0');
}

function formatDate(value) {
  if (!value) return '—';
  return new Date(value + 'T00:00').toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric'
  });
}

function peso(n) {
  return '₱' + n.toLocaleString('en-PH', {
    minimumFractionDigits: 2, maximumFractionDigits: 2
  });
}

function setToday() {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  date.value = local.toISOString().slice(0, 10);
}

// Live order summary
function updateSummary() {
  const q = parseInt(qty.value, 10);
  const c = parseFloat(cost.value);

  document.getElementById('sum-supplier').textContent = supplier.value || '—';
  document.getElementById('sum-item').textContent = item.value || '—';
  document.getElementById('sum-qty').textContent = q > 0 ? q : '—';
  document.getElementById('sum-date').textContent = formatDate(date.value);
  document.getElementById('sum-total').textContent =
    q > 0 && c >= 0 ? peso(q * c) : '—';
}

function showToast(message) {
  document.getElementById('toast-text').textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3500);
}

function addRow(no, q) {
  const row = document.createElement('div');
  row.className = 'list-item new';

  const noBox = document.createElement('div');
  noBox.className = 'po-no';
  noBox.textContent = no;

  const info = document.createElement('div');
  info.className = 'text-block';

  const title = document.createElement('div');
  title.className = 'title';
  title.textContent = supplier.value;

  const sub = document.createElement('div');
  sub.className = 'subtitle';
  sub.textContent = item.value + ' · ' + q + (q === 1 ? ' unit' : ' units') +
    ' · ' + formatDate(date.value);

  info.append(title, sub);

  const status = document.createElement('div');
  status.className = 'status ordered';
  status.textContent = 'Ordered';

  row.append(noBox, info, status);
  recentHeader.after(row); // newest goes on top
}

function refreshNumbers() {
  const label = poNumber(nextNumber);
  document.getElementById('sum-no').textContent = label;
  document.getElementById('next-po').textContent = 'Next: ' + label;
}

form.addEventListener('input', updateSummary);
form.addEventListener('change', updateSummary);

// Native "required" and "min" checks run first, so this only fires when valid
form.addEventListener('submit', function (e) {
  e.preventDefault();

  const q = parseInt(qty.value, 10);
  const no = poNumber(nextNumber);

  addRow(no, q);
  showToast(no + ' was saved with status “Ordered”.');

  nextNumber++;
  form.reset();
});

form.addEventListener('reset', function () {
  setTimeout(function () {
    setToday();
    refreshNumbers();
    updateSummary();
  }, 0);
});

setToday();
updateSummary();
